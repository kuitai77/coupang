# Google AI 모드 바코드 자동 검색

여러 컴퓨터가 같은 `coupang GTIN Checker` Google Sheets에서 작업합니다.
컴퓨터 수나 작업 번호를 정하지 않고 Windows 컴퓨터 이름으로 처리 중인 행을 구분합니다.

## 실행

각 컴퓨터에서 `AI모드_자동검색_실행.cmd`를 더블클릭합니다.

- AI 모드가 로그아웃 상태에서 정상 작동하면 로그인하지 않고 진행합니다.
- 위에서부터 `확인여부`가 빈 첫 데이터 행을 찾으면 `확인중|컴퓨터이름|시간|고유값`을 먼저 기록합니다.
- 쓰기 직전과 선점 후 두 번 상태를 확인하고 자신의 행일 때만 검색합니다.
- 답변은 `결과` 열에 입력하고 `확인여부`는 `확인완료`로 변경합니다.
- 다른 컴퓨터가 처리 중인 행과 이미 완료된 행은 건너뜁니다.
- 같은 바코드의 완료 답변이 있으면 다시 검색하지 않고 기존 답변을 사용합니다.
- 복사 전 클립보드 값이 남아 있어도 이전 바코드 답변은 저장하지 않습니다.
- AI가 답변을 제공할 수 없다는 화면을 표시하면 같은 바코드 번호만 넣어 한 번 더 검색합니다.
- 비정상 종료로 남은 `확인중` 행은 기본 180분이 지나면 다시 처리할 수 있습니다.
- 기본 검색 간격은 20초입니다.
- 캡차가 나오면 Chrome에서 직접 처리한 뒤 실행 창에서 Enter를 누릅니다.

검색 결과는 공유 시트의 `결과` 열에 즉시 저장되므로 별도의 결과 통합 작업은 하지 않습니다.

명령줄 실행:

```powershell
.\run_ai_mode_sheet.ps1 --sheet-url "Google Sheets 주소" --delay 30
.\run_ai_mode_sheet.ps1 --sheet-url "Google Sheets 주소" --max-items 10
.\run_ai_mode_sheet.ps1 --sheet-url "Google Sheets 주소" --dry-run
```

## 폴더 구성

- `AI모드_자동검색_실행.cmd`: 공유 Google Sheets 자동 검색 실행
- `run_ai_mode_sheet.ps1`: 공유 시트 실행기
- `.artifact-work/ai_mode_sheet_worker.mjs`: 검색 및 행 선점 처리

`run_ai_mode.ps1`, `AI모드_결과통합_실행.cmd`, `ai_mode_prepare.py`는 이전 로컬 Excel 방식의 보관 파일이며 현재 공유 시트 방식에서는 사용하지 않습니다.
