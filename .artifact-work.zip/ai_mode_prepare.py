from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from gtin_core import check_barcode, find_header, normalize_text, read_first_worksheet


def select_barcode(row: list[str], barcode_columns: list[int]) -> str:
    for index in barcode_columns:
        if index >= len(row):
            continue
        checked = check_barcode(row[index])
        if checked.structural_status == "VALID":
            return checked.cleaned_value
    return ""


def prepare(input_path: Path, output_path: Path) -> None:
    sheet_name, headers, rows = read_first_worksheet(input_path)
    barcode_columns = [
        find_header(headers, "협력사 상품바코드"),
        find_header(headers, "컴퓨존 상품바코드", 0),
        find_header(headers, "컴퓨존 상품바코드", 1),
    ]
    selected_rows: list[dict[str, object]] = []
    last_row = 1
    for source_row, row in enumerate(rows, start=2):
        last_row = source_row
        barcode = select_barcode(row, barcode_columns)
        if barcode:
            selected_rows.append({"rowIndex": source_row - 1, "barcode": barcode})

    payload = {
        "sheetName": sheet_name,
        "headers": [normalize_text(value) for value in headers],
        "rowCount": last_row,
        "rows": selected_rows,
    }
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")


def main() -> int:
    if len(sys.argv) != 3:
        print("사용법: ai_mode_prepare.py 입력.xlsx 출력.json", file=sys.stderr)
        return 2
    prepare(Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
