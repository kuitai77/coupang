@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0run_ai_mode_sheet.ps1" --sheet-url "https://docs.google.com/spreadsheets/d/1dIXB1bDtD0NdWjVgWj6Cm8o7NZ4F_wD-rYtNatgJNps/edit?gid=0#gid=0" %*
set "EXIT_CODE=%ERRORLEVEL%"
echo.
if not "%EXIT_CODE%"=="0" echo The program ended with error code %EXIT_CODE%.
if not "%~1"=="" exit /b %EXIT_CODE%
pause
exit /b %EXIT_CODE%
