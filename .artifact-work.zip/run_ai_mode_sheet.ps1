param(
    [Parameter(ValueFromRemainingArguments = $true)]
    [string[]]$ToolArguments
)

$ErrorActionPreference = 'Stop'
$env:NODE_NO_WARNINGS = '1'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$toolPath = Join-Path $scriptRoot '.artifact-work\ai_mode_sheet_worker.mjs'
$moduleSource = Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\node\node_modules'
$moduleLink = Join-Path $scriptRoot '.artifact-work\node_modules'
if ((Test-Path -LiteralPath $moduleSource) -and -not (Test-Path -LiteralPath $moduleLink)) {
    New-Item -ItemType Junction -Path $moduleLink -Target $moduleSource | Out-Null
}

$bundledNode = Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe'
if (Test-Path -LiteralPath $bundledNode) {
    & $bundledNode $toolPath @ToolArguments
    exit $LASTEXITCODE
}

$nodeCommand = Get-Command node -ErrorAction SilentlyContinue
if ($nodeCommand) {
    & $nodeCommand.Source $toolPath @ToolArguments
    exit $LASTEXITCODE
}

Write-Error '실행에 필요한 Node.js를 찾을 수 없습니다. Codex 런타임 또는 Node.js를 설치해 주세요.'
