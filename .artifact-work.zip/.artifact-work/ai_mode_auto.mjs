import fs from "node:fs/promises";
import path from "node:path";
import process from "node:process";
import readline from "node:readline/promises";
import crypto from "node:crypto";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";
import { chromium } from "playwright";

const ROOT = path.resolve(path.dirname(new URL(import.meta.url).pathname.replace(/^\/(?:[A-Za-z]:)/, (m) => m.slice(1))), "..");
const WORKSPACE_ROOT = path.resolve(ROOT, "..");
const DEFAULT_PROFILE = path.join(process.env.LOCALAPPDATA || path.join(ROOT, "data"), "GTIN-AIMode", "chrome_profile");
const CHROME_PATHS = [
  "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",
  "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe",
];
const execFileAsync = promisify(execFile);

function parseArgs(argv) {
  const options = {
    input: null,
    output: null,
    profile: DEFAULT_PROFILE,
    cache: null,
    delaySeconds: 20,
    maxQueries: 0,
    timeoutSeconds: 150,
    workerId: 1,
    workerCount: 1,
    refresh: false,
    dryRun: false,
    mergeOnly: false,
    mergeCacheDir: null,
  };
  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    const take = () => {
      if (i + 1 >= argv.length) throw new Error(`값이 필요한 옵션입니다: ${arg}`);
      i += 1;
      return argv[i];
    };
    if (arg === "--input") options.input = take();
    else if (arg === "--output") options.output = take();
    else if (arg === "--profile") options.profile = take();
    else if (arg === "--cache") options.cache = take();
    else if (arg === "--delay") options.delaySeconds = Number(take());
    else if (arg === "--max-queries") options.maxQueries = Number(take());
    else if (arg === "--timeout") options.timeoutSeconds = Number(take());
    else if (arg === "--worker-id") options.workerId = Number(take());
    else if (arg === "--worker-count") options.workerCount = Number(take());
    else if (arg === "--refresh") options.refresh = true;
    else if (arg === "--dry-run") options.dryRun = true;
    else if (arg === "--merge-only") options.mergeOnly = true;
    else if (arg === "--merge-cache-dir") options.mergeCacheDir = take();
    else if (arg === "--help" || arg === "-h") options.help = true;
    else if (!arg.startsWith("-") && !options.input) options.input = arg;
    else throw new Error(`알 수 없는 옵션: ${arg}`);
  }
  if (!Number.isFinite(options.delaySeconds) || options.delaySeconds < 5) {
    throw new Error("--delay는 5초 이상이어야 합니다.");
  }
  if (!Number.isInteger(options.maxQueries) || options.maxQueries < 0) {
    throw new Error("--max-queries는 0 이상의 정수여야 합니다.");
  }
  if (!Number.isFinite(options.timeoutSeconds) || options.timeoutSeconds < 30) {
    throw new Error("--timeout은 30초 이상이어야 합니다.");
  }
  if (!Number.isInteger(options.workerCount) || options.workerCount < 1) {
    throw new Error("--worker-count는 1 이상의 정수여야 합니다.");
  }
  if (!Number.isInteger(options.workerId) || options.workerId < 1 || options.workerId > options.workerCount) {
    throw new Error("--worker-id는 1부터 --worker-count 사이여야 합니다.");
  }
  return options;
}

function printHelp() {
  console.log(`Google AI 모드 바코드 자동 검색

사용법:
  .\\run_ai_mode.ps1 [입력.xlsx]
  .\\run_ai_mode.ps1 --input 입력.xlsx --delay 20 --max-queries 100

옵션:
  --input PATH         입력 Excel 파일
  --output PATH        결과 Excel 파일
  --delay SECONDS      검색 사이 대기 시간 (기본 20초, 최소 5초)
  --max-queries N      이번 실행의 신규 검색 수 (0은 제한 없음)
  --timeout SECONDS    한 검색의 최대 대기 시간 (기본 150초)
  --worker-id N        이 컴퓨터 번호 (1부터 시작)
  --worker-count N     전체 컴퓨터 수
  --refresh            저장된 답변도 다시 검색
  --dry-run            검색하지 않고 대상 수만 확인
  --merge-only         data 폴더의 작업자 캐시를 합쳐 최종 Excel 생성
  --merge-cache-dir    작업자 캐시 파일을 모아 둔 폴더

AI 모드가 로그아웃 상태에서 열리면 로그인하지 않고 그대로 진행합니다.
캡차가 나타나면 프로그램이 멈추며, 사용자가 직접 완료한 뒤 Enter를 누르면 계속합니다.`);
}

async function exists(filePath) {
  try {
    await fs.access(filePath);
    return true;
  } catch {
    return false;
  }
}

async function findDefaultInput() {
  const entries = await fs.readdir(WORKSPACE_ROOT, { withFileTypes: true });
  const candidates = [];
  for (const entry of entries) {
    if (!entry.isFile()) continue;
    if (!/^오픈마켓팀_상품바코드.*\.xlsx$/i.test(entry.name)) continue;
    if (/(검증결과|AI모드결과)/i.test(entry.name)) continue;
    const fullPath = path.join(WORKSPACE_ROOT, entry.name);
    const stat = await fs.stat(fullPath);
    candidates.push({ fullPath, modified: stat.mtimeMs });
  }
  candidates.sort((a, b) => b.modified - a.modified);
  if (!candidates.length) {
    throw new Error("현재 폴더에서 '오픈마켓팀_상품바코드*.xlsx' 파일을 찾을 수 없습니다.");
  }
  return candidates[0].fullPath;
}

function normalizeHeader(value) {
  return String(value ?? "").normalize("NFKC").replace(/\s+/g, "").trim();
}

async function loadCache(cachePath) {
  if (!(await exists(cachePath))) return { version: 1, answers: {} };
  try {
    const parsed = JSON.parse(await fs.readFile(cachePath, "utf8"));
    if (!parsed || typeof parsed.answers !== "object") throw new Error("answers 없음");
    return parsed;
  } catch (error) {
    throw new Error(`답변 캐시 파일을 읽을 수 없습니다: ${error.message}`);
  }
}

async function saveCache(cachePath, cache) {
  await fs.mkdir(path.dirname(cachePath), { recursive: true });
  const tempPath = `${cachePath}.tmp`;
  await fs.writeFile(tempPath, JSON.stringify(cache, null, 2), "utf8");
  await fs.rename(tempPath, cachePath);
}

function workerSuffix(workerId, workerCount) {
  if (workerCount <= 1) return "";
  const width = Math.max(2, String(workerCount).length);
  return `_worker_${String(workerId).padStart(width, "0")}_of_${String(workerCount).padStart(width, "0")}`;
}

function assignedToWorker(barcode, workerId, workerCount) {
  const digest = crypto.createHash("sha256").update(String(barcode), "utf8").digest();
  return digest.readUInt32BE(0) % workerCount === workerId - 1;
}

async function loadAllWorkerCaches(cacheDirectory) {
  const combined = { version: 1, answers: {} };
  if (!(await exists(cacheDirectory))) return combined;
  const entries = await fs.readdir(cacheDirectory, { withFileTypes: true });
  const names = entries
    .filter((entry) => entry.isFile() && /^ai_mode_answers(?:_worker_\d+_of_\d+)?\.json$/i.test(entry.name))
    .map((entry) => entry.name)
    .sort();
  for (const name of names) {
    const cache = await loadCache(path.join(cacheDirectory, name));
    for (const [barcode, record] of Object.entries(cache.answers)) {
      if (record?.answer) combined.answers[barcode] = record;
    }
  }
  console.log(`통합한 캐시 파일: ${names.length}개`);
  return combined;
}

async function findChrome() {
  for (const chromePath of CHROME_PATHS) {
    if (await exists(chromePath)) return chromePath;
  }
  throw new Error("Google Chrome 실행 파일을 찾을 수 없습니다.");
}

async function findPython() {
  const bundled = path.join(
    process.env.USERPROFILE || "",
    ".cache",
    "codex-runtimes",
    "codex-primary-runtime",
    "dependencies",
    "python",
    "python.exe",
  );
  if (await exists(bundled)) return bundled;
  return "python";
}

async function prepareInput(inputPath) {
  const jobPath = path.join(ROOT, "data", `.ai_mode_job_${process.pid}.json`);
  await fs.mkdir(path.dirname(jobPath), { recursive: true });
  try {
    await execFileAsync(
      await findPython(),
      [path.join(ROOT, "ai_mode_prepare.py"), inputPath, jobPath],
      { cwd: ROOT, windowsHide: true, encoding: "utf8", maxBuffer: 1024 * 1024 },
    );
    return JSON.parse(await fs.readFile(jobPath, "utf8"));
  } finally {
    await fs.rm(jobPath, { force: true }).catch(() => {});
  }
}

function cleanAnswer(value) {
  return String(value ?? "")
    .replace(/\r\n/g, "\n")
    .replace(/\u00a0/g, " ")
    .replace(/\n+(?:출처|Sources)\s*:\s*\n[\s\S]*$/i, "")
    .replace(/\n*AI 대답에는 오류가 있을 수 있습니다\.?\s*(?:자세히 알아보기)?\s*$/i, "")
    .replace(/[ \t]+\n/g, "\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim()
    .slice(0, 32767);
}

async function fallbackAnswerFromDom(copyButton) {
  return copyButton.evaluate((button) => {
    let root = button.parentElement;
    for (let depth = 0; root && depth < 10; depth += 1, root = root.parentElement) {
      const paragraphs = [...root.querySelectorAll(".n6owBd.awi2gc")]
        .map((node) => (node.innerText || "").trim())
        .filter(Boolean);
      if (paragraphs.length) return paragraphs.join("\n\n");
    }
    return "";
  });
}

async function hasBlockPage(page) {
  const bodyText = await page.locator("body").innerText({ timeout: 5000 }).catch(() => "");
  return /captcha|자동입력\s*방지|비정상적인\s*트래픽|unusual traffic|로봇이\s*아닙니다/i.test(bodyText);
}

async function waitForUser(message) {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  try {
    await rl.question(`${message}\n완료 후 Enter를 누르세요: `);
  } finally {
    rl.close();
  }
}

async function fetchAiModeAnswer(page, context, barcode, timeoutMs) {
  const url = `https://www.google.com/search?udm=50&q=${encodeURIComponent(barcode)}`;
  await page.goto(url, { waitUntil: "domcontentloaded", timeout: 60000 });

  const copyButton = page.getByRole("button", { name: /^(텍스트 복사|Copy text)$/i }).last();
  try {
    await copyButton.waitFor({ state: "visible", timeout: timeoutMs });
  } catch (error) {
    if (await hasBlockPage(page)) {
      await waitForUser("Google 확인 화면 또는 캡차가 열렸습니다. Chrome 창에서 직접 처리해 주세요.");
      await page.goto(url, { waitUntil: "domcontentloaded", timeout: 60000 });
      await copyButton.waitFor({ state: "visible", timeout: timeoutMs });
    } else {
      throw new Error(`AI 답변이 ${Math.round(timeoutMs / 1000)}초 안에 완료되지 않았습니다.`);
    }
  }

  await context.grantPermissions(["clipboard-read", "clipboard-write"], {
    origin: "https://www.google.com",
  }).catch(() => {});
  await copyButton.click({ timeout: 10000 });
  await page.waitForTimeout(500);

  let answer = await page.evaluate(async () => {
    try {
      return await navigator.clipboard.readText();
    } catch {
      return "";
    }
  });
  answer = cleanAnswer(answer);
  if (!answer) answer = cleanAnswer(await fallbackAnswerFromDom(copyButton));
  if (!answer) throw new Error("AI 답변 본문을 복사하지 못했습니다.");
  return answer;
}

async function exportWorkbook(inputPath, job, resultColumn, rowAnswers, outputPath) {
  console.log("결과 Excel을 만드는 중입니다. 원본 크기에 따라 몇 분 걸릴 수 있습니다.");
  const workbook = await SpreadsheetFile.importXlsx(await FileBlob.load(inputPath));
  const sheet = workbook.worksheets.getItemAt(0);
  const matrix = [["AI 모드 결과"]];
  for (let rowIndex = 1; rowIndex < job.rowCount; rowIndex += 1) {
    matrix.push([rowAnswers.get(rowIndex) ?? ""]);
  }
  const resultRange = sheet.getRangeByIndexes(0, resultColumn, job.rowCount, 1);
  resultRange.values = matrix;
  resultRange.format.columnWidth = 70;
  if (job.rowCount > 1) {
    const bodyRange = sheet.getRangeByIndexes(1, resultColumn, job.rowCount - 1, 1);
    bodyRange.format.wrapText = true;
    bodyRange.format.verticalAlignment = "top";
  }
  const headerRange = sheet.getRangeByIndexes(0, resultColumn, 1, 1);
  headerRange.format = {
    fill: "#DCDCDC",
    font: { color: "#000000" },
    horizontalAlignment: "center",
    verticalAlignment: "center",
    wrapText: true,
  };

  const columnName = columnLetters(resultColumn + 1);
  console.log((await workbook.inspect({
    kind: "table",
    range: `${sheet.name}!${columnName}1:${columnName}${Math.min(job.rowCount, 8)}`,
    include: "values,formulas",
    tableMaxRows: 8,
    tableMaxCols: 1,
    maxChars: 2500,
  })).ndjson);
  console.log((await workbook.inspect({
    kind: "match",
    searchTerm: "#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A|#NUM!|#NULL!|#SPILL!|#CALC!",
    options: { useRegex: true, maxResults: 100 },
    summary: "AI 모드 결과 열 오류 검사",
    maxChars: 2500,
  })).ndjson);

  await fs.mkdir(path.dirname(outputPath), { recursive: true });
  const exported = await SpreadsheetFile.exportXlsx(workbook);
  await exported.save(outputPath);
}

function columnLetters(number) {
  let result = "";
  let current = number;
  while (current > 0) {
    current -= 1;
    result = String.fromCharCode(65 + (current % 26)) + result;
    current = Math.floor(current / 26);
  }
  return result;
}

async function main() {
  const options = parseArgs(process.argv.slice(2));
  if (options.help) {
    printHelp();
    return;
  }

  const inputPath = path.resolve(options.input || await findDefaultInput());
  if (!(await exists(inputPath))) throw new Error(`입력 파일이 없습니다: ${inputPath}`);
  const suffix = workerSuffix(options.workerId, options.workerCount);
  const defaultOutputName = options.mergeOnly
    ? `${path.basename(inputPath, path.extname(inputPath))}_AI모드결과_통합.xlsx`
    : `${path.basename(inputPath, path.extname(inputPath))}_AI모드결과${suffix}.xlsx`;
  const outputPath = path.resolve(options.output || path.join(ROOT, "output", defaultOutputName));
  const profilePath = path.resolve(options.profile);
  const cachePath = path.resolve(options.cache || path.join(ROOT, "data", `ai_mode_answers${suffix}.json`));

  console.log(`입력 파일: ${inputPath}`);
  console.log(`결과 파일: ${outputPath}`);
  console.log(`검색 간격: ${options.delaySeconds}초`);
  if (!options.mergeOnly) console.log(`작업 컴퓨터: ${options.workerId}/${options.workerCount}`);

  const job = await prepareInput(inputPath);
  if (!Array.isArray(job.rows) || job.rowCount < 2) throw new Error("입력 Excel에 상품 행이 없습니다.");
  const headers = job.headers || [];

  let resultColumn = headers.findIndex((header) => normalizeHeader(header) === "AI모드결과");
  if (resultColumn < 0) resultColumn = headers.length;

  const barcodeRows = new Map();
  for (const item of job.rows) {
    const barcode = String(item.barcode || "");
    const rowIndex = Number(item.rowIndex);
    if (!barcode || !Number.isInteger(rowIndex) || rowIndex < 1) continue;
    if (!barcodeRows.has(barcode)) barcodeRows.set(barcode, []);
    barcodeRows.get(barcode).push(rowIndex);
  }

  const cache = options.mergeOnly
    ? await loadAllWorkerCaches(path.resolve(options.mergeCacheDir || path.join(ROOT, "data")))
    : await loadCache(cachePath);
  const rowAnswers = new Map();
  if (!options.refresh || options.mergeOnly) {
    for (const [barcode, rows] of barcodeRows) {
      const answer = cleanAnswer(cache.answers[barcode]?.answer);
      if (!answer) continue;
      for (const rowIndex of rows) rowAnswers.set(rowIndex, answer);
    }
  }
  const assignedBarcodes = options.mergeOnly
    ? [...barcodeRows.keys()]
    : [...barcodeRows.keys()].filter((barcode) => assignedToWorker(barcode, options.workerId, options.workerCount));
  const pending = assignedBarcodes.filter((barcode) => options.refresh || !cache.answers[barcode]?.answer);
  const limitedPending = options.maxQueries > 0 ? pending.slice(0, options.maxQueries) : pending;

  console.log(`상품 행: ${job.rowCount - 1}개`);
  console.log(`유효한 고유 바코드: ${barcodeRows.size}개`);
  console.log(`이 컴퓨터 담당 바코드: ${assignedBarcodes.length}개`);
  console.log(`저장된 답변 재사용: ${assignedBarcodes.length - pending.length}개`);
  console.log(`이번 실행 신규 검색: ${options.mergeOnly ? 0 : limitedPending.length}개`);
  if (options.dryRun) return;

  if (options.mergeOnly) {
    await exportWorkbook(inputPath, job, resultColumn, rowAnswers, outputPath);
    console.log(`통합 결과 저장 완료: ${outputPath}`);
    console.log(`답변이 입력된 행: ${rowAnswers.size.toLocaleString()}개`);
    return;
  }

  let context = null;
  let stopRequested = false;
  process.on("SIGINT", () => {
    if (!stopRequested) {
      stopRequested = true;
      console.log("\n현재 검색을 마친 뒤 결과를 저장하고 종료합니다.");
    }
  });

  try {
    if (limitedPending.length) {
      await fs.mkdir(profilePath, { recursive: true });
      context = await chromium.launchPersistentContext(profilePath, {
        executablePath: await findChrome(),
        headless: false,
        viewport: null,
        args: ["--start-maximized"],
      });
      const pages = context.pages();
      const page = pages[0] || await context.newPage();
      await page.goto("https://www.google.com/ai", { waitUntil: "domcontentloaded", timeout: 60000 });

      let consecutiveErrors = 0;
      for (let index = 0; index < limitedPending.length; index += 1) {
        if (stopRequested) break;
        const barcode = limitedPending[index];
        console.log(`[${index + 1}/${limitedPending.length}] ${barcode} 검색 중...`);
        try {
          const answer = await fetchAiModeAnswer(
            page,
            context,
            barcode,
            options.timeoutSeconds * 1000,
          );
          cache.answers[barcode] = { answer, updatedAt: new Date().toISOString() };
          await saveCache(cachePath, cache);
          for (const rowIndex of barcodeRows.get(barcode) || []) rowAnswers.set(rowIndex, answer);
          consecutiveErrors = 0;
          console.log(`  완료 (${answer.length.toLocaleString()}자)`);
        } catch (error) {
          consecutiveErrors += 1;
          console.error(`  실패: ${error.message}`);
          if (consecutiveErrors >= 3) {
            console.error("연속 3회 실패하여 현재까지의 결과를 저장하고 중단합니다.");
            break;
          }
        }
        if (!stopRequested && index + 1 < limitedPending.length) {
          await page.waitForTimeout(options.delaySeconds * 1000);
        }
      }
    }
  } finally {
    if (context) await context.close().catch(() => {});
    for (const [barcode, rows] of barcodeRows) {
      const answer = cleanAnswer(cache.answers[barcode]?.answer);
      if (!answer) continue;
      for (const rowIndex of rows) rowAnswers.set(rowIndex, answer);
    }
    await exportWorkbook(inputPath, job, resultColumn, rowAnswers, outputPath);
    console.log(`결과 저장 완료: ${outputPath}`);
    console.log(`답변이 입력된 행: ${rowAnswers.size.toLocaleString()}개`);
  }
}

main().catch((error) => {
  console.error(`오류: ${error?.stack || error}`);
  process.exitCode = 1;
});
