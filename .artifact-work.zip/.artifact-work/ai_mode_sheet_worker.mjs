import crypto from "node:crypto";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import process from "node:process";
import readline from "node:readline/promises";
import { chromium } from "playwright";

const ROOT = path.resolve(path.dirname(new URL(import.meta.url).pathname.replace(/^\/(?:[A-Za-z]:)/, (m) => m.slice(1))), "..");
const DEFAULT_PROFILE = path.join(process.env.LOCALAPPDATA || path.join(ROOT, "data"), "GTIN-AIMode", "sheet_chrome_profile");

function parseArgs(argv) {
  const options = {
    sheetUrl: "",
    delaySeconds: 20,
    timeoutSeconds: 150,
    staleMinutes: 180,
    maxItems: 0,
    profile: DEFAULT_PROFILE,
    dryRun: false,
  };
  for (let index = 0; index < argv.length; index += 1) {
    const arg = argv[index];
    const take = () => {
      if (index + 1 >= argv.length) throw new Error(`값이 필요한 옵션입니다: ${arg}`);
      index += 1;
      return argv[index];
    };
    if (arg === "--sheet-url") options.sheetUrl = take();
    else if (arg === "--delay") options.delaySeconds = Number(take());
    else if (arg === "--timeout") options.timeoutSeconds = Number(take());
    else if (arg === "--stale-minutes") options.staleMinutes = Number(take());
    else if (arg === "--max-items") options.maxItems = Number(take());
    else if (arg === "--profile") options.profile = take();
    else if (arg === "--dry-run") options.dryRun = true;
    else if (arg === "--help" || arg === "-h") options.help = true;
    else throw new Error(`알 수 없는 옵션: ${arg}`);
  }
  if (!options.help && !options.sheetUrl) throw new Error("--sheet-url이 필요합니다.");
  if (!Number.isFinite(options.delaySeconds) || options.delaySeconds < 5) throw new Error("--delay는 5초 이상이어야 합니다.");
  if (!Number.isFinite(options.timeoutSeconds) || options.timeoutSeconds < 30) throw new Error("--timeout은 30초 이상이어야 합니다.");
  if (!Number.isFinite(options.staleMinutes) || options.staleMinutes < 10) throw new Error("--stale-minutes는 10분 이상이어야 합니다.");
  if (!Number.isInteger(options.maxItems) || options.maxItems < 0) throw new Error("--max-items는 0 이상의 정수여야 합니다.");
  return options;
}

function printHelp() {
  console.log(`Google Sheets + AI 모드 공동 작업기

사용법:
  .\\run_ai_mode_sheet.ps1 --sheet-url "Google Sheets 주소"

동작:
  확인여부가 빈 행을 찾음
  확인중|컴퓨터이름|시간|고유값 으로 선점
  선점 상태를 다시 확인한 뒤 AI 모드 검색
  결과 열에 답변을 넣고 확인여부를 확인완료로 변경

옵션:
  --delay SECONDS       검색 간격 (기본 20초, 최소 5초)
  --timeout SECONDS     AI 답변 최대 대기 시간 (기본 150초)
  --stale-minutes N     멈춘 확인중 행 회수 시간 (기본 180분)
  --max-items N         이번 실행 처리 행 수 (0은 제한 없음)
  --dry-run             시트를 수정하지 않고 현황만 확인`);
}

async function exists(filePath) {
  try {
    await fs.access(filePath);
    return true;
  } catch {
    return false;
  }
}

async function findChrome() {
  const paths = [
    "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",
    "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe",
  ];
  for (const chromePath of paths) if (await exists(chromePath)) return chromePath;
  throw new Error("Google Chrome 실행 파일을 찾을 수 없습니다.");
}

function parseSheetIdentity(url) {
  const id = String(url).match(/\/spreadsheets\/d\/([a-zA-Z0-9-_]+)/)?.[1];
  const gid = String(url).match(/[?#&]gid=(\d+)/)?.[1] || "0";
  if (!id) throw new Error("Google Sheets 주소에서 문서 ID를 찾을 수 없습니다.");
  return { id, gid };
}

function parseCsv(text) {
  const rows = [];
  let row = [];
  let cell = "";
  let quoted = false;
  for (let index = 0; index < text.length; index += 1) {
    const char = text[index];
    if (quoted) {
      if (char === '"' && text[index + 1] === '"') {
        cell += '"';
        index += 1;
      } else if (char === '"') {
        quoted = false;
      } else {
        cell += char;
      }
    } else if (char === '"') {
      quoted = true;
    } else if (char === ",") {
      row.push(cell);
      cell = "";
    } else if (char === "\n") {
      row.push(cell.replace(/\r$/, ""));
      rows.push(row);
      row = [];
      cell = "";
    } else {
      cell += char;
    }
  }
  if (cell || row.length) {
    row.push(cell.replace(/\r$/, ""));
    rows.push(row);
  }
  return rows;
}

function normalizeHeader(value) {
  return String(value ?? "").normalize("NFKC").replace(/\s+/g, "").trim();
}

function calculateCheckDigit(body) {
  let total = 0;
  const reversed = [...body].reverse();
  for (let index = 0; index < reversed.length; index += 1) {
    total += Number(reversed[index]) * (index % 2 === 0 ? 3 : 1);
  }
  return (10 - total % 10) % 10;
}

function normalizeBarcode(value) {
  let barcode = String(value ?? "").normalize("NFKC").trim();
  if (barcode.startsWith("√")) barcode = barcode.slice(1).trim();
  barcode = barcode.replace(/[\s-]/g, "");
  if (!/^\d+$/.test(barcode) || ![8, 12, 13, 14].includes(barcode.length)) return "";
  if (calculateCheckDigit(barcode.slice(0, -1)) !== Number(barcode.at(-1))) return "";
  return barcode;
}

function indexesFor(headers) {
  const normalized = headers.map(normalizeHeader);
  const status = normalized.indexOf("확인여부");
  const result = normalized.indexOf("결과");
  const barcodes = [];
  normalized.forEach((header, index) => {
    if ((header === "협력사상품바코드" || header === "컴퓨존상품바코드") && !barcodes.includes(index)) {
      barcodes.push(index);
    }
  });
  if (status < 0 || result < 0 || !barcodes.length) {
    throw new Error("필수 열을 찾을 수 없습니다: 확인여부, 결과, 상품바코드");
  }
  return { status, result, barcodes };
}

function barcodeForRow(row, barcodeIndexes) {
  for (const index of barcodeIndexes) {
    const barcode = normalizeBarcode(row[index]);
    if (barcode) return barcode;
  }
  return "";
}

function isProcessingStatus(status) {
  const value = String(status).trim();
  return value === "확인중" || value.startsWith("확인중|") || value.startsWith("처리중|");
}

function isStaleClaim(status, staleMinutes) {
  if (!isProcessingStatus(status)) return false;
  const timestamp = String(status).split("|")[2];
  const checkedAt = Date.parse(timestamp);
  return Number.isFinite(checkedAt) && Date.now() - checkedAt > staleMinutes * 60_000;
}

async function fetchRows(context, identity) {
  const url = `https://docs.google.com/spreadsheets/d/${identity.id}/export?format=csv&gid=${identity.gid}&_=${Date.now()}`;
  const response = await context.request.get(url, { timeout: 60_000 });
  if (!response.ok()) throw new Error(`Google Sheets 읽기 실패: HTTP ${response.status()}`);
  const text = await response.text();
  if (/^\s*</.test(text)) throw new Error("Google Sheets가 CSV 대신 로그인 또는 오류 화면을 반환했습니다.");
  return parseCsv(text.replace(/^\uFEFF/, ""));
}

function columnLetters(number) {
  let result = "";
  let current = number;
  while (current > 0) {
    current -= 1;
    result = String.fromCharCode(65 + current % 26) + result;
    current = Math.floor(current / 26);
  }
  return result;
}

async function writeCell(page, address, value) {
  const nameBox = page.locator("#t-name-box");
  const editor = page.locator("#waffle-rich-text-editor");
  await nameBox.waitFor({ state: "visible", timeout: 60_000 });
  await nameBox.click();
  await nameBox.fill(address);
  await nameBox.press("Enter");
  await page.waitForTimeout(500);
  if (String(value) === "") {
    await page.keyboard.press("Delete");
    await page.keyboard.press("Enter");
  } else {
    // Google Sheets does not always accept insertText immediately after the
    // name box changes the selection. Enter explicit cell-edit mode and fill
    // its contenteditable editor so Korean and long AI answers are committed.
    await page.keyboard.press("F2");
    await editor.waitFor({ state: "visible", timeout: 10_000 });
    await editor.focus();
    await editor.fill(String(value));
    await editor.press("Enter");
  }
  await page.waitForTimeout(1800);
}

async function cellValue(context, identity, rowNumber, columnIndex) {
  const rows = await fetchRows(context, identity);
  return String(rows[rowNumber - 1]?.[columnIndex] ?? "");
}

function cleanAnswer(value) {
  return String(value ?? "")
    .replace(/\r\n/g, "\n")
    .replace(/\u00a0/g, " ")
    .replace(/\n+(?:출처|Sources)\s*:\s*\n[\s\S]*$/i, "")
    .replace(/\n*AI 대답에는 오류가 있을 수 있습니다\.?\s*(?:자세히 알아보기)?\s*$/i, "")
    .replace(/\s*\n+\s*/g, " ")
    .replace(/[ \t]{2,}/g, " ")
    .trim()
    .slice(0, 32767);
}

const NO_ANSWER_PATTERN = /이 검색에 대해 제공해 드릴 수 있는 (?:대답|답변)이 없는 것 같습니다|다른 질문을 해 보세요|(?:can't|cannot) provide an answer|try asking another question/i;
const NO_ANSWER_RESULT = "이 검색에 대해 제공해 드릴 수 있는 답변이 없습니다. 한 번 더 검색했지만 동일한 응답이 표시되었습니다.";

function hasConflictingBarcode(answer, barcode) {
  const codes = String(answer).match(/(?<!\d)\d{12,14}(?!\d)/g) || [];
  return codes.length > 0 && !codes.includes(barcode);
}

async function fallbackAnswerFromDom(copyButton) {
  return copyButton.evaluate((button) => {
    let root = button.parentElement;
    for (let depth = 0; root && depth < 10; depth += 1, root = root.parentElement) {
      const paragraphs = [...root.querySelectorAll(".n6owBd.awi2gc")]
        .map((node) => (node.innerText || "").trim())
        .filter(Boolean);
      if (paragraphs.length) return paragraphs.join("\n\n");
    }
    return "";
  });
}

async function readClipboard(page) {
  return page.evaluate(async () => {
    try {
      return await navigator.clipboard.readText();
    } catch {
      return "";
    }
  });
}

async function waitForAiOutcome(page, copyButton, timeoutMs) {
  const noAnswer = page.getByText(NO_ANSWER_PATTERN).first();
  return Promise.race([
    copyButton.waitFor({ state: "visible", timeout: timeoutMs }).then(() => "answer"),
    noAnswer.waitFor({ state: "visible", timeout: timeoutMs }).then(() => "no-answer"),
  ]);
}

async function hasBlockPage(page) {
  const bodyText = await page.locator("body").innerText({ timeout: 5000 }).catch(() => "");
  return /captcha|자동입력\s*방지|비정상적인\s*트래픽|unusual traffic|로봇이\s*아닙니다/i.test(bodyText);
}

async function waitForUser(message) {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  try {
    await rl.question(`${message}\n완료 후 Enter를 누르세요: `);
  } finally {
    rl.close();
  }
}

async function fetchAiModeAnswer(page, context, barcode, timeoutMs) {
  await context.grantPermissions(["clipboard-read", "clipboard-write"], { origin: "https://www.google.com" }).catch(() => {});
  const queries = [barcode, barcode];
  for (let attempt = 0; attempt < queries.length; attempt += 1) {
    const url = `https://www.google.com/search?udm=50&q=${encodeURIComponent(queries[attempt])}&_=${Date.now()}`;
    await page.goto(url, { waitUntil: "domcontentloaded", timeout: 60_000 });
    const copyButton = page.getByRole("button", { name: /^(텍스트 복사|Copy text)$/i }).last();
    let outcome;
    try {
      outcome = await waitForAiOutcome(page, copyButton, timeoutMs);
    } catch {
      if (!(await hasBlockPage(page))) throw new Error(`AI 답변이 ${Math.round(timeoutMs / 1000)}초 안에 완료되지 않았습니다.`);
      await waitForUser("Google 확인 화면 또는 캡차가 열렸습니다. Chrome 창에서 직접 처리해 주세요.");
      await page.goto(url, { waitUntil: "domcontentloaded", timeout: 60_000 });
      outcome = await waitForAiOutcome(page, copyButton, timeoutMs);
    }

    if (outcome === "no-answer") {
      if (attempt === 0) {
        console.log("  AI가 답변을 제공하지 않아 한 번 더 검색합니다.");
        continue;
      }
      return NO_ANSWER_RESULT;
    }

    // Read the answer currently displayed on the page first. This avoids
    // accidentally saving the previous search result when the OS clipboard
    // has not finished updating after the copy-button click.
    let answer = cleanAnswer(await fallbackAnswerFromDom(copyButton));
    if (answer && !hasConflictingBarcode(answer, barcode)) return answer;

    const clipboardBefore = cleanAnswer(await readClipboard(page));
    await copyButton.click({ timeout: 10_000 });
    for (let waitCount = 0; waitCount < 20; waitCount += 1) {
      await page.waitForTimeout(250);
      const clipboardAfter = cleanAnswer(await readClipboard(page));
      const isFresh = clipboardAfter && (clipboardAfter !== clipboardBefore || clipboardAfter.includes(barcode));
      if (isFresh && !hasConflictingBarcode(clipboardAfter, barcode)) return clipboardAfter;
    }

    if (attempt === 0) {
      console.log("  현재 바코드의 답변을 확인하지 못해 한 번 더 검색합니다.");
      continue;
    }
    throw new Error("현재 바코드와 일치하는 AI 답변을 가져오지 못했습니다.");
  }
  throw new Error("AI 답변 본문을 가져오지 못했습니다.");
}

function sheetSnapshot(rows, columns, staleMinutes) {
  const completedByBarcode = new Map();
  const busyBarcodes = new Set();
  const candidates = [];
  let completed = 0;
  let processing = 0;
  for (let index = 1; index < rows.length; index += 1) {
    const row = rows[index] || [];
    const barcode = barcodeForRow(row, columns.barcodes);
    if (!barcode) continue;
    const status = String(row[columns.status] ?? "").trim();
    const result = cleanAnswer(row[columns.result]);
    if (status === "확인완료") {
      completed += 1;
      if (result) completedByBarcode.set(barcode, result);
    } else if (isProcessingStatus(status) && !isStaleClaim(status, staleMinutes)) {
      processing += 1;
      busyBarcodes.add(barcode);
    } else if (!status || isStaleClaim(status, staleMinutes)) {
      candidates.push({ rowNumber: index + 1, barcode });
    }
  }
  return { completedByBarcode, busyBarcodes, candidates, completed, processing };
}

async function main() {
  const options = parseArgs(process.argv.slice(2));
  if (options.help) {
    printHelp();
    return;
  }
  const identity = parseSheetIdentity(options.sheetUrl);
  const hostname = os.hostname().replace(/[^A-Za-z0-9가-힣_-]/g, "_") || "PC";
  const profilePath = path.resolve(options.profile);
  await fs.mkdir(profilePath, { recursive: true });

  console.log(`컴퓨터 이름: ${hostname}`);
  console.log(`검색 간격: ${options.delaySeconds}초`);
  const context = await chromium.launchPersistentContext(profilePath, {
    executablePath: await findChrome(),
    headless: false,
    viewport: null,
    args: ["--start-maximized"],
  });
  let stopRequested = false;
  process.on("SIGINT", () => {
    stopRequested = true;
    console.log("\n현재 작업을 마친 뒤 종료합니다.");
  });

  try {
    const pages = context.pages();
    const sheetPage = pages[0] || await context.newPage();
    await sheetPage.goto(options.sheetUrl, { waitUntil: "domcontentloaded", timeout: 60_000 });
    await sheetPage.locator("#t-name-box").waitFor({ state: "visible", timeout: 60_000 });
    const aiPage = await context.newPage();
    let rows = await fetchRows(context, identity);
    const columns = indexesFor(rows[0] || []);
    const statusColumn = columnLetters(columns.status + 1);
    const resultColumn = columnLetters(columns.result + 1);
    let snapshot = sheetSnapshot(rows, columns, options.staleMinutes);
    console.log(`완료: ${snapshot.completed.toLocaleString()}행`);
    console.log(`다른 컴퓨터 처리 중: ${snapshot.processing.toLocaleString()}행`);
    console.log(`현재 선택 가능: ${snapshot.candidates.length.toLocaleString()}행`);
    if (options.dryRun) return;

    let completedHere = 0;
    let consecutiveErrors = 0;
    let consecutiveClaimWriteFailures = 0;
    while (!stopRequested && (options.maxItems === 0 || completedHere < options.maxItems)) {
      rows = await fetchRows(context, identity);
      snapshot = sheetSnapshot(rows, columns, options.staleMinutes);
      const candidates = snapshot.candidates.filter((item) => !snapshot.busyBarcodes.has(item.barcode));
      if (!candidates.length) {
        console.log("현재 선점 가능한 행이 없습니다. 다른 컴퓨터가 처리 중인 행은 건너뜁니다.");
        break;
      }
      // Always take the first available data row. Coordination is handled by
      // the claim token below, so computer-name-based row offsets are neither
      // necessary nor intuitive to the operator.
      const target = candidates[0];
      const token = crypto.randomBytes(4).toString("hex");
      const claim = `확인중|${hostname}|${new Date().toISOString()}|${token}`;
      const statusAddress = `${statusColumn}${target.rowNumber}`;
      const resultAddress = `${resultColumn}${target.rowNumber}`;

      await sheetPage.waitForTimeout(Number.parseInt(token.slice(0, 3), 16) % 1500);
      const beforeClaim = await cellValue(context, identity, target.rowNumber, columns.status);
      if (beforeClaim && !isStaleClaim(beforeClaim, options.staleMinutes)) {
        console.log(`[${target.rowNumber}행] 선점 직전에 다른 컴퓨터가 가져가 건너뜁니다.`);
        continue;
      }
      await writeCell(sheetPage, statusAddress, claim);
      let observed = await cellValue(context, identity, target.rowNumber, columns.status);
      if (observed !== claim) {
        if (!observed) {
          consecutiveClaimWriteFailures += 1;
          console.error(`[${target.rowNumber}행] 확인여부 셀에 확인중 값을 저장하지 못했습니다. (${consecutiveClaimWriteFailures}/3)`);
          if (consecutiveClaimWriteFailures >= 3) {
            throw new Error("Google Sheets 셀 입력이 3회 연속 반영되지 않았습니다. 시트 편집 권한과 Chrome 창의 오류 표시를 확인해 주세요.");
          }
        } else {
          consecutiveClaimWriteFailures = 0;
          console.log(`[${target.rowNumber}행] 다른 컴퓨터가 먼저 선점하여 건너뜁니다.`);
        }
        continue;
      }
      consecutiveClaimWriteFailures = 0;
      await sheetPage.waitForTimeout(2500);
      observed = await cellValue(context, identity, target.rowNumber, columns.status);
      if (observed !== claim) {
        console.log(`[${target.rowNumber}행] 선점 상태가 변경되어 건너뜁니다.`);
        continue;
      }

      console.log(`[${target.rowNumber}행] ${target.barcode} - ${hostname} 처리 중`);
      try {
        const reusableAnswer = snapshot.completedByBarcode.get(target.barcode);
        const reused = reusableAnswer && !hasConflictingBarcode(reusableAnswer, target.barcode)
          ? reusableAnswer
          : "";
        const answer = reused || await fetchAiModeAnswer(
          aiPage,
          context,
          target.barcode,
          options.timeoutSeconds * 1000,
        );
        if (hasConflictingBarcode(answer, target.barcode)) {
          throw new Error("다른 바코드의 답변이 감지되어 결과를 저장하지 않았습니다.");
        }
        const finalClaim = await cellValue(context, identity, target.rowNumber, columns.status);
        if (finalClaim !== claim) {
          console.log("  완료 전에 선점 상태가 변경되어 결과를 쓰지 않았습니다.");
          continue;
        }
        await writeCell(sheetPage, resultAddress, answer);
        const savedAnswer = cleanAnswer(await cellValue(context, identity, target.rowNumber, columns.result));
        if (savedAnswer !== answer) throw new Error("결과 셀 저장 확인에 실패했습니다.");
        await writeCell(sheetPage, statusAddress, "확인완료");
        completedHere += 1;
        consecutiveErrors = 0;
        console.log(`  ${reused ? "기존 동일 바코드 답변 재사용" : "AI 검색 완료"} (${answer.length.toLocaleString()}자)`);
      } catch (error) {
        consecutiveErrors += 1;
        console.error(`  실패: ${error.message}`);
        const currentClaim = await cellValue(context, identity, target.rowNumber, columns.status).catch(() => "");
        if (currentClaim === claim) await writeCell(sheetPage, statusAddress, "").catch(() => {});
        if (consecutiveErrors >= 3) {
          console.error("연속 3회 실패하여 중단합니다.");
          break;
        }
      }
      if (!stopRequested) await aiPage.waitForTimeout(options.delaySeconds * 1000);
    }
    console.log(`이 컴퓨터에서 완료한 행: ${completedHere.toLocaleString()}개`);
  } finally {
    await context.close().catch(() => {});
  }
}

main().catch((error) => {
  console.error(`오류: ${error?.stack || error}`);
  process.exitCode = 1;
});
