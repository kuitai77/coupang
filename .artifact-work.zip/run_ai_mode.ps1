param(
    [Parameter(ValueFromRemainingArguments = $true)]
    [string[]]$ToolArguments
)

$ErrorActionPreference = 'Stop'
$env:NODE_NO_WARNINGS = '1'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$toolPath = Join-Path $scriptRoot '.artifact-work\ai_mode_auto.mjs'
$moduleSource = Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\node\node_modules'
$moduleLink = Join-Path $scriptRoot '.artifact-work\node_modules'
if ((Test-Path -LiteralPath $moduleSource) -and -not (Test-Path -LiteralPath $moduleLink)) {
    New-Item -ItemType Junction -Path $moduleLink -Target $moduleSource | Out-Null
}

if (-not $ToolArguments -or $ToolArguments.Count -eq 0) {
    $configDir = Join-Path $scriptRoot 'data'
    $safeComputerName = ($env:COMPUTERNAME -replace '[^A-Za-z0-9_-]', '_')
    $configPath = Join-Path $configDir "ai_mode_worker_$safeComputerName.json"
    if (Test-Path -LiteralPath $configPath) {
        $config = Get-Content -Raw -LiteralPath $configPath | ConvertFrom-Json
        $workerCount = [int]$config.workerCount
        $workerId = [int]$config.workerId
    } else {
        Write-Host '여러 컴퓨터에서 나누어 실행할 수 있습니다.'
        $workerCountText = Read-Host '전체 컴퓨터 수 (한 대만 사용하면 1)'
        if ([string]::IsNullOrWhiteSpace($workerCountText)) { $workerCountText = '1' }
        $workerCount = [int]$workerCountText
        $workerIdText = Read-Host "이 컴퓨터 번호 (1~$workerCount)"
        if ([string]::IsNullOrWhiteSpace($workerIdText)) { $workerIdText = '1' }
        $workerId = [int]$workerIdText
        if ($workerCount -lt 1 -or $workerId -lt 1 -or $workerId -gt $workerCount) {
            throw '컴퓨터 번호 설정이 올바르지 않습니다.'
        }
        New-Item -ItemType Directory -Force -Path $configDir | Out-Null
        @{ workerCount = $workerCount; workerId = $workerId } |
            ConvertTo-Json |
            Set-Content -LiteralPath $configPath -Encoding UTF8
    }
    $ToolArguments = @('--worker-count', [string]$workerCount, '--worker-id', [string]$workerId)
}

$bundledNode = Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe'
if (Test-Path -LiteralPath $bundledNode) {
    & $bundledNode $toolPath @ToolArguments
    exit $LASTEXITCODE
}

$nodeCommand = Get-Command node -ErrorAction SilentlyContinue
if ($nodeCommand) {
    & $nodeCommand.Source $toolPath @ToolArguments
    exit $LASTEXITCODE
}

Write-Error '실행에 필요한 Node.js를 찾을 수 없습니다. Codex 런타임 또는 Node.js를 설치해 주세요.'
